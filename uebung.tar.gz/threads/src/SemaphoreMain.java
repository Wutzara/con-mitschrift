import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SemaphoreMain {
    ExecutorService executor = Executors.newFixedThreadPool(5);
    private Semaphore semaphore;
    
    public SemaphoreMain() {
        semaphore = new Semaphore();
        for (int i = 0; i < 5; i++) {
            executor.submit(new Runnable() {

                @Override
                public void run() {
                    semaphore.aquire();
                    System.out.printf("Ich bin jetzt dran\n");
                    try {
                        Thread.sleep(500);
                    } catch(Exception e){
                        e.printStackTrace();
                    }
                    semaphore.release();
                }

            });
        }
        executor.shutdown();
    }

    public static void main(String[] args) {
        SemaphoreMain sm = new SemaphoreMain();
    }
}
