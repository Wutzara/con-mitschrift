
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HelloWorldThreads {
    ExecutorService executor = Executors.newFixedThreadPool(5);

    public HelloWorldThreads() {
        for (int i = 0; i < 5; i++) {
            executor.submit(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(2000);
                    } catch(InterruptedException e) {
                        System.out.printf("cancel Thread now\n");
                    }
                }
            });
        }
        executor.shutdownNow();
    }

}
