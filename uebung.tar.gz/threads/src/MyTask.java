
public class MyTask implements Runnable {

    @Override
    public void run() {

    }

}
