
public class Semaphore {
    private int betriebsmittel;

    public Semaphore() {
        this.betriebsmittel = 0;
    }

    public synchronized void aquire() {
        while(betriebsmittel != 0) {
            try {
                wait();
            } catch (InterruptedException e) {

            }
        }
        betriebsmittel++;
    }

    public synchronized void release() {
        betriebsmittel--;
        notifyAll();
    }

}
