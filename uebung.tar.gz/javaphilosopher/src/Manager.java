import java.util.ArrayList;
import java.util.List;

public class Manager {
    List<Gabel> gabeln = new ArrayList<Gabel>();

}
