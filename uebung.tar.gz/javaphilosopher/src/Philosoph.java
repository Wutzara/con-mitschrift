
public class Philosoph {

   enum STATE {
       THINKING,
       HUNGRY,
       EATING
   }

   private STATE zustand;
}
