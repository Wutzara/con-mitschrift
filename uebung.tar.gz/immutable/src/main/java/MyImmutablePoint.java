import java.awt.Point;

/*
 * @author gunibert, @date 22.10.15 15:15
 */
final public class MyImmutablePoint {

    private final Point point;

    public MyImmutablePoint(Point point) {
        super();
        this.point = point;
    }

    public MyImmutablePoint() {
        this(new Point(0,0));
    }

    public int x() {
        return point.x;
    }

    public int y() {
        return point.y;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("MyImmutablePoint [point=");
        sb.append(point);
        sb.append("]");
        return sb.toString();
    }

    public static void main(String[] args) {
        //MyImmutablePoint p = new MyImmutablePoint(new Point(10,15));
        MyPoint p = new MyPoint(10, 15);
        
        System.out.printf("distance: %f\n", p.getDistance());
    }

}
