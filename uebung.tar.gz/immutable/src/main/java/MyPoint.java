
public class MyPoint {
    private final double x, y;
    private double distance;

    public MyPoint(final double x, final double y) {
        this.x = x;
        this.y = y;
        this.distance = Double.NaN;
    }

    /**
     * @return the x
     */
    public double getX() {
        return x;
    }

    /**
     * @return the y
     */
    public double getY() {
        return y;
    }

    public double getDistance() {
        // lazy - only calculate distance only once if you ever need it
        if(Double.isNaN(this.distance )) {
            this.distance = Math.sqrt(Math.pow(this.x, 2) + Math.pow(this.y, 2));
        }
        return this.distance;
    }
}
