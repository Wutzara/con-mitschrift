
import java.awt.*;
import java.util.concurrent.Semaphore;

class FixedPhilosopher extends Thread {
  private int identity;
  private PhilCanvas view;
  private Diners controller;
  private Fork left;
  private Fork right;

  FixedPhilosopher(Diners ctr, int id, Fork l, Fork r) {
    controller = ctr; view = ctr.display;
    identity = id; left = l; right = r;
  }

  public void run() {
    try {
      while (true) {
        //thinking
        view.setPhil(identity,view.THINKING);
        sleep(controller.sleepTime());
        //hungry
        view.setPhil(identity,view.HUNGRY);
        if(identity % 2 == 0) {
        	// gerader Philosoph
        	left.get();
        	view.setPhil(identity,view.GOTLEFT);
            sleep(500);
            right.get();
            
        } else {
        	// ungerader Philosoph
        	right.get();
        	view.setPhil(identity,view.GOTRIGHT);
            sleep(500);
            left.get();
            
        }
        
        //gotright chopstick
        //eating
        view.setPhil(identity,view.EATING);
        sleep(controller.eatTime());
        right.put();
        left.put();
      }
    } catch (java.lang.InterruptedException e) {}
  }
}
