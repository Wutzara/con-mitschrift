
import java.awt.*;
import java.util.concurrent.Semaphore;

class ButlerPhilosopher extends Thread {
	private int identity;
	private PhilCanvas view;
	private Diners controller;
	private Fork left;
	private Fork right;
	private Semaphore butler;

	ButlerPhilosopher(Diners ctr, int id, Fork l, Fork r, Semaphore butler) {
		controller = ctr;
		view = ctr.display;
		identity = id;
		left = l;
		right = r;
		this.butler = butler;
	}

	public void run() {
		try {
			while (true) {
				// thinking
				view.setPhil(identity, view.THINKING);
				sleep(controller.sleepTime());
				// hungry
				butler.acquire();
				right.get();
				view.setPhil(identity, view.GOTRIGHT);
				sleep(500);
				left.get();

				// gotright chopstick
				// eating
				view.setPhil(identity, view.EATING);
				sleep(controller.eatTime());
				right.put();
				left.put();
				butler.release();
			}
		} catch (java.lang.InterruptedException e) {
		}
	}
}
