package org.sample;

public class RationaleZahlAenderbar {

    private int zaehler;
    private int nenner;

    public RationaleZahlAenderbar(int zaehler, int nenner) {
        if (nenner == 0) {
            throw new RuntimeException("nenner ist null");
        }
        // optimize nenner
        int teiler = ggt(zaehler, nenner);
        this.zaehler = zaehler / teiler;
        this.nenner = nenner / teiler;
    }

    public RationaleZahlAenderbar mul(RationaleZahlAenderbar other) {
        int newzaehler = this.getZaehler() * other.getZaehler();
        int newnenner  = this.getNenner()  * other.getNenner();

        return new RationaleZahlAenderbar(newzaehler, newnenner);
    }

    synchronized public void add(RationaleZahlAenderbar other) {
        int basis = this.getNenner() * other.getNenner();
        int zaehler = this.getZaehler() * other.getNenner() +
            other.getZaehler() * this.getNenner();
        int teiler = ggt(basis, zaehler);
        this.nenner = basis / teiler;
        this.zaehler = zaehler / teiler;
    }

    /**
     * @return the zaehler
     */
    public int getZaehler() {
        return zaehler;
    }

    /**
     * @return the nenner
     */
    public int getNenner() {
        return nenner;
    }

    public static int ggt(int a, int b) {
        if (a == b) return a;
        if (a <  b) return ggt(a, b - a);
        else        return ggt(a - b, b);
    }

    @Override
    public String toString() {
        return String.format("%d/%d", this.getZaehler(), this.getNenner());
    }
}
