import java.util.concurrent.atomic.AtomicInteger;

public class RationaleZahlAenderbarAtomic {

    private AtomicInteger zaehler;
    private AtomicInteger nenner;

    public RationaleZahlAenderbarAtomic(int zaehler, int nenner) {
        if (nenner == 0) {
            throw new RuntimeException("nenner ist null");
        }
        // optimize nenner
        int teiler = ggt(zaehler, nenner);
        this.zaehler = new AtomicInteger(zaehler / teiler);
        this.nenner = new AtomicInteger(nenner / teiler);
    }

    public RationaleZahlAenderbarAtomic mul(RationaleZahlAenderbarAtomic other) {
        int newzaehler = this.getZaehler() * other.getZaehler();
        int newnenner  = this.getNenner()  * other.getNenner();

        return new RationaleZahlAenderbarAtomic(newzaehler, newnenner);
    }

    public void add(RationaleZahlAenderbarAtomic other) {
        int basis = this.getNenner() * other.getNenner();
        int zaehler = this.getZaehler() * other.getNenner() +
            other.getZaehler() * this.getNenner();
        int teiler = ggt(basis, zaehler);
        this.nenner.getAndSet(basis / teiler);
        this.zaehler.getAndSet(zaehler / teiler);
    }

    public static void main(String[] args) {
        RationaleZahlAenderbarAtomic a1 = new RationaleZahlAenderbarAtomic(2, 10);
        RationaleZahlAenderbarAtomic a2 = new RationaleZahlAenderbarAtomic(1, 5);

        System.out.printf("%s\n%s\n", a1.toString(), a2.toString());
        a1.add(a2);
        System.out.printf("%s\n", a1.toString());
    }

    /**
     * @return the zaehler
     */
    public int getZaehler() {
        return zaehler.get();
    }

    /**
     * @return the nenner
     */
    public int getNenner() {
        return nenner.get();
    }

    public static int ggt(int a, int b) {
        if (a == b) return a;
        if (a <  b) return ggt(a, b - a);
        else        return ggt(a - b, b);
    }

    @Override
    public String toString() {
        return String.format("%d/%d", this.getZaehler(), this.getNenner());
    }
}
