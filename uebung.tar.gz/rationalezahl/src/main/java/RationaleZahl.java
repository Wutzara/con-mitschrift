
public class RationaleZahl {

    final int zaehler;
    final int nenner;

    public RationaleZahl(int zaehler, int nenner) {
        this.zaehler = zaehler;
        this.nenner = nenner;
    }

    public RationaleZahl mul(RationaleZahl other) {
        int newzaehler = this.getZaehler() * other.getZaehler();
        int newnenner  = this.getNenner()  * other.getNenner();

        return new RationaleZahl(newzaehler, newnenner);
    }

    public RationaleZahl add(RationaleZahl other) {
        int basis = this.getNenner() * other.getNenner();
        int zaehler = this.getZaehler() * other.getNenner() +
            other.getZaehler() * this.getNenner();
        int teiler = ggt(basis, zaehler);
        basis = basis / teiler;
        zaehler = zaehler / teiler;

        return new RationaleZahl(zaehler, basis);
    }

    /**
     * @return the zaehler
     */
    public int getZaehler() {
        return zaehler;
    }

    /**
     * @return the nenner
     */
    public int getNenner() {
        return nenner;
    }

    public static int ggt(int a, int b) {
        if (a == b) return a;
        if (a <  b) return ggt(a, b - a);
        else        return ggt(a - b, b);
    }

    @Override
    public String toString() {
        return String.format("%d/%d", this.getZaehler(), this.getNenner());
    }
}
