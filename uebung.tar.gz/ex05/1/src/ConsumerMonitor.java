import java.nio.file.Path;
import java.util.Queue;
import java.util.concurrent.BlockingQueue;

public class ConsumerMonitor implements Runnable {
	private QueueMonitor queue;
    private boolean run = true;

    /**
     *
     */
    public ConsumerMonitor(QueueMonitor queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        while(run){
        	
            try {
                Path p = (Path)queue.poll();
                handlePath(p);
            } catch(Exception e){
                e.printStackTrace();
            }
        }
    }

	private void handlePath(Path p) {
		if(p.toString().equals("wearedone")) {
			run = false;
		} else {
			System.out.printf("File: %s\n", p.getFileName());
		}
	}
}
