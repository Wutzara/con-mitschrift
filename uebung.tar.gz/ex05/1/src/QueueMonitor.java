import java.nio.file.Path;
import java.util.Queue;

public class QueueMonitor {
	private final Queue<Path> queue;
	
	public QueueMonitor(Queue<Path> queue)
	{
		this.queue = queue;
	}
	
	synchronized public void offer(Path e)
	{
		boolean notify = false;
		if(queue.isEmpty()) notify=true; 
		queue.offer(e);																																																																																																																																																																																																																																																																																						
		if(notify)
			notifyAll();
	}
	
	synchronized public Path poll() {
		if(queue.isEmpty())
			try {
				wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		return queue.poll();
	}
}

