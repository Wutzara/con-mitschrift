import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.PriorityQueue;
import java.util.Queue;

public class ProducerMonitor extends SimpleFileVisitor<Path> implements Runnable{
	private final QueueMonitor queue;
	private final int consumer;
	
	public ProducerMonitor(QueueMonitor queue, int consumer)
	{
		this.queue = queue;
		this.consumer = consumer;
	}
	
	@Override
	public void run() {
		try {
			Path path = Paths.get("/home/gunibert/development");
            Files.walkFileTree(path, this);
            for(int i = 0; i < consumer; ++i) {
            	Path poisonPill = Paths.get("wearedone");
            	queue.offer(poisonPill);
            }
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
		if(file.toString().matches(".*\\.(java|cpp|h)")) {
            try {
                queue.offer(file);
            } catch(Exception e){
                e.printStackTrace();
            }
        }

        return FileVisitResult.CONTINUE;
	}

	public static void main(String[] args) {
		Queue<Path> queue = new PriorityQueue<Path>();
		QueueMonitor q = new QueueMonitor(queue);
		ProducerMonitor p = new ProducerMonitor(q, 1);
		ConsumerMonitor c = new ConsumerMonitor(q);
		
		new Thread(p).start();
		new Thread(c).start();
	}
}
