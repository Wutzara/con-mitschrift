import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class Producer extends SimpleFileVisitor<Path> implements Runnable {
    private final BlockingQueue<Path> queue;
    private final int consumer;
    public static boolean done = false;

    public Producer(BlockingQueue<Path> queue, int consumer)
    {
        this.queue = queue;
        this.consumer = consumer;
    }

    @Override
    public void run() {
        try {
            Path path = Paths.get("/home/gunibert/development");
            Files.walkFileTree(path, this);
            for(int i = 0; i < consumer; ++i) {
            	Path poisonPill = Paths.get("wearedone");
            	queue.put(poisonPill);
            }
            done = true;
        } catch(IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public FileVisitResult visitFile(Path file, BasicFileAttributes arg1) throws IOException {

        if(file.toString().matches(".*\\.(java|cpp|h)")) {
            try {
                queue.put(file);
            } catch(Exception e){
                e.printStackTrace();
            }
        }

        return FileVisitResult.CONTINUE;
    }

    public static void main(String[] args) {
        BlockingQueue<Path> queue = new LinkedBlockingQueue<Path>();
        Producer p = new Producer(queue, 1);
        //Consumer c = new Consumer(queue);
        
        //new Thread(c).start();
        new Thread(p).start();
 
        
        while(!done) {
        	queue.parallelStream().map(path -> path.toString()).forEach(System.out::println);        	
        }
        System.out.println("done");
        //queue.stream().map(path -> path.toString()).forEach(System.out::println);
    }

}
