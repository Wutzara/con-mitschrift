import java.time.LocalDate;
import java.time.Month;

/*
 * @author gunibert, @date 23.10.15 17:58
 */
public class Ostern {
    public static int ostern(int jahr) {
        int a = jahr % 19;
        int b = jahr % 4;
        int c = jahr % 7;
        int k = jahr / 100;
        int p = (8 * k + 13) / 25;
        int q = k / 4;
        int M = (15 + k - p - q) % 30;
        int N = (4 + k - q) % 7;
        int d = (19 * a + M) % 30;
        int e = (2 * b + 4 * c + 6 * d + N) % 7;
        return 22 + d + e;
    }

    public static LocalDate datumOstersonntag(int jahr)
    {
        int tagMaerzApril = ostern(jahr);
        int tag = tagMaerzApril > 31 ? tagMaerzApril - 31 : tagMaerzApril;
        Month monat = tagMaerzApril > 31 ? Month.APRIL : Month.MARCH;
        return LocalDate.of(jahr, monat, tag);
    }

    public static void main(String args[]) {
        LocalDate o = Ostern.datumOstersonntag(2015);
        System.out.printf("%s\n", o.toString());
    }
}
